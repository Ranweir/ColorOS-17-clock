package com.example.glassclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object ClockRenderer {

    private const val W = 600
    private const val H = 340

    private const val RED = 0xFFFF3B30.toInt()
    private const val GLOW_LEFT = 0xDDFF4D6D.toInt()
    private const val GLOW_RIGHT = 0xDD6FA8FF.toInt()

    fun render(ctx: Context): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val tf = Typeface.createFromAsset(ctx.assets, "GlassDigits.ttf")
        val now = Calendar.getInstance()
        val is24 = DateFormat.is24HourFormat(ctx)
        val hour = if (is24) now.get(Calendar.HOUR_OF_DAY)
        else (now.get(Calendar.HOUR) .let { if (it == 0) 12 else it })
        val minute = now.get(Calendar.MINUTE)

        val digits = listOf(hour / 10, hour % 10, minute / 10, minute % 10)

        // date
        val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xB3FFFFFF.toInt()
            textSize = 30f
            textAlign = Paint.Align.CENTER
        }
        val date = SimpleDateFormat("d MMM EEE", Locale.ENGLISH).format(now.time)
        c.drawText(date, W / 2f, 40f, datePaint)

        val textSize = 262f
        val top = 70f
        val baseline = 292f
        val cell = 120f
        val colonCell = 56f
        val total = cell * 4 + colonCell
        val startX = (W - total) / 2f

        val centers = floatArrayOf(
            startX + cell * 0.5f,
            startX + cell * 1.5f,
            startX + cell * 2f + colonCell + cell * 0.5f,
            startX + cell * 3f + colonCell + cell * 0.5f
        )
        val colonX = startX + cell * 2f + colonCell / 2f

        for (i in 0..3) {
            val isRed = i < 2 && digits[i] == 1
            drawGlassText(
                c, digits[i].toString(), centers[i], baseline, top, textSize, tf,
                red = isRed,
                glow = if (i < 2) GLOW_LEFT else GLOW_RIGHT
            )
        }
        drawGlassText(c, ":", colonX, baseline, top, textSize, tf, red = false, glow = GLOW_RIGHT)

        return bmp
    }

    private fun drawGlassText(
        c: Canvas, text: String, cx: Float, baseline: Float, top: Float,
        size: Float, tf: Typeface, red: Boolean, glow: Int
    ) {
        val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = tf
            textSize = size
            textAlign = Paint.Align.CENTER
        }

        // 1) glow pass
        val glowPaint = Paint(base).apply {
            style = Paint.Style.FILL
            color = if (red) 0x55FF3B30 else 0x40FFFFFF
            setShadowLayer(26f, 0f, 0f, if (red) RED else glow)
        }
        c.drawText(text, cx, baseline, glowPaint)

        // 2) frosted gradient fill (bright top, faded bottom)
        val fill = Paint(base).apply {
            style = Paint.Style.FILL
            shader = if (red) {
                LinearGradient(0f, top, 0f, baseline,
                    intArrayOf(0xF0FF3B30.toInt(), 0x99FF3B30.toInt()), null, Shader.TileMode.CLAMP)
            } else {
                LinearGradient(0f, top, 0f, baseline,
                    intArrayOf(0xC8FFFFFF.toInt(), 0x55FFFFFF), null, Shader.TileMode.CLAMP)
            }
        }
        c.drawText(text, cx, baseline, fill)

        // 3) thin glass edge
        val stroke = Paint(base).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            color = if (red) 0xAAFF8A80.toInt() else 0x80FFFFFF.toInt()
        }
        c.drawText(text, cx, baseline, stroke)
    }
}
