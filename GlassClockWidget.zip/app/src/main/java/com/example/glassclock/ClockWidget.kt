package com.example.glassclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(context, mgr, ids)
        scheduleNext(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNext(context)
    }

    override fun onDisabled(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(tickIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, ClockWidget::class.java))
                if (ids.isNotEmpty()) {
                    updateAll(context, mgr, ids)
                    scheduleNext(context)
                }
            }
        }
    }

    private fun updateAll(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val bmp = ClockRenderer.render(context)
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_clock)
            views.setImageViewBitmap(R.id.clock_image, bmp)
            mgr.updateAppWidget(id, views)
        }
    }

    private fun scheduleNext(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val next = (System.currentTimeMillis() / 60000L + 1) * 60000L
        am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(context))
    }

    private fun tickIntent(context: Context): PendingIntent {
        val i = Intent(context, ClockWidget::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(
            context, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object {
        const val ACTION_TICK = "com.example.glassclock.TICK"
    }
}
